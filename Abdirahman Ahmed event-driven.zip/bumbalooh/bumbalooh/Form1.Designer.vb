﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ButtonLogin = New System.Windows.Forms.Button()
        Me.password = New System.Windows.Forms.TextBox()
        Me.Label1Password = New System.Windows.Forms.Label()
        Me.Label1Username = New System.Windows.Forms.Label()
        Me.email = New System.Windows.Forms.TextBox()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ButtonLogin
        '
        Me.ButtonLogin.BackColor = System.Drawing.Color.OrangeRed
        Me.ButtonLogin.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonLogin.Location = New System.Drawing.Point(315, 206)
        Me.ButtonLogin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonLogin.Name = "ButtonLogin"
        Me.ButtonLogin.Size = New System.Drawing.Size(111, 46)
        Me.ButtonLogin.TabIndex = 0
        Me.ButtonLogin.Text = "Login"
        Me.ButtonLogin.UseVisualStyleBackColor = False
        '
        'password
        '
        Me.password.Location = New System.Drawing.Point(226, 170)
        Me.password.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.password.Name = "password"
        Me.password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.password.Size = New System.Drawing.Size(200, 23)
        Me.password.TabIndex = 1
        '
        'Label1Password
        '
        Me.Label1Password.AutoSize = True
        Me.Label1Password.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Label1Password.Location = New System.Drawing.Point(226, 123)
        Me.Label1Password.Name = "Label1Password"
        Me.Label1Password.Size = New System.Drawing.Size(96, 30)
        Me.Label1Password.TabIndex = 2
        Me.Label1Password.Text = "Password"
        '
        'Label1Username
        '
        Me.Label1Username.AutoSize = True
        Me.Label1Username.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Label1Username.Location = New System.Drawing.Point(226, 42)
        Me.Label1Username.Name = "Label1Username"
        Me.Label1Username.Size = New System.Drawing.Size(88, 30)
        Me.Label1Username.TabIndex = 3
        Me.Label1Username.Text = "Email iD"
        '
        'email
        '
        Me.email.Location = New System.Drawing.Point(226, 88)
        Me.email.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(200, 23)
        Me.email.TabIndex = 4
        '
        'ButtonExit
        '
        Me.ButtonExit.BackColor = System.Drawing.Color.Orange
        Me.ButtonExit.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonExit.Location = New System.Drawing.Point(198, 206)
        Me.ButtonExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(111, 46)
        Me.ButtonExit.TabIndex = 5
        Me.ButtonExit.Text = "Exit"
        Me.ButtonExit.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ClientSize = New System.Drawing.Size(700, 338)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.email)
        Me.Controls.Add(Me.Label1Username)
        Me.Controls.Add(Me.Label1Password)
        Me.Controls.Add(Me.password)
        Me.Controls.Add(Me.ButtonLogin)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ButtonLogin As Button
    Friend WithEvents password As TextBox
    Friend WithEvents Label1Password As Label
    Friend WithEvents Label1Username As Label
    Friend WithEvents email As TextBox
    Friend WithEvents ButtonExit As Button
End Class
