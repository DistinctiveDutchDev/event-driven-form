﻿Public Class Form2

    Private Sub Label6Room_Click(sender As Object, e As EventArgs) Handles Label6Room.Click

    End Sub

    Private Sub TextBox3Price_TextChanged(sender As Object, e As EventArgs) Handles TextBox3Price.TextChanged, TextBoxPrice.TextChanged

    End Sub

    Private Sub Button1Option_Click(sender As Object, e As EventArgs) Handles Button1Option.Click
        Button1Option.BackColor = SystemColors.Control
        Button2Option.BackColor = SystemColors.Control
        Button3Option.BackColor = SystemColors.Control
        Button4Option.BackColor = SystemColors.Control

    End Sub

    Private Sub TextBox2Adress_keyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2Adress.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "1234567890abcdefghijklmnopqrstuvwxyz "

            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a character")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If
    End Sub

    Private Sub Button7Exit_Click(sender As Object, e As EventArgs) Handles Button7Exit.Click, ButtonExit.Click
        'we're using the me.close function to exit the form when this button is pressed
        Me.Close()


    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GroupBox2.Enabled = False
        GroupBox3.Enabled = False

        If GroupBox1.Visible Then
            GroupBox2.Hide()
            GroupBox3.Hide()

        Else
            GroupBox1.Show()
        End If



    End Sub

    Private Sub Button5Clear_Click(sender As Object, e As EventArgs) Handles Button5Clear.Click, ButtonClear.Click
        'we're using the .clear to clear all the values and restart the form when the clear button is pressed
        Me.Controls.Clear()
        InitializeComponent()
        Form2_Load(e, e)





    End Sub

    Private Sub Button6Calculate_Click(sender As Object, e As EventArgs) Handles Button6Calculate.Click
        'we're declaring the variables of the numerical updowns so we can have a clear overview of the formula used to calculate the room dimensions
        Dim Length As Double = NUDLength.Value
        Dim Width As Double = NUDWidth.Value
        Dim height As Double = NUDHeighth.Value
        'here we're declaring the formula for the total as a double
        Dim totals As Double = (2 * Length * height) + (Width * height * 2)


        NUDAnswer.Value = CStr(totals)
        NUDApprox.Value = NUDAnswer.Value / 2.5
        'we use the math.ceiling to round up our value
        NUDExact.Value = Math.Ceiling(NUDAnswer.Value / 2.5)
        NUDCalculate.Value = NUDExact.Value * NUDMessage.Value






    End Sub

    Private Sub Button8Calculate_Click(sender As Object, e As EventArgs) Handles Button8Calculate.Click

        Button8Calculate.Show()

        NUDCalculate.Value = NUDExact.Value * NUDMessage.Value
        TextBoxPrice.Text = NUDCalculate.Value

    End Sub

    Private Sub ListBox1Wallpaper_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1Wallpaper.SelectedIndexChanged

    End Sub

    Private Sub Label12Message_Click(sender As Object, e As EventArgs) Handles Label12Message.Click

    End Sub

    Private Sub NUDExact_ValueChanged(sender As Object, e As EventArgs) Handles NUDExact.ValueChanged

    End Sub

    Private Sub ButtonContinue_Click(sender As Object, e As EventArgs) Handles ButtonContinue.Click
        If TextBox1Name.Text = "" Or TextBox2Adress.Text = "" Then
            MessageBox.Show("Input your address and/or name")
        Else
            GroupBox2.Enabled = True
            GroupBox1.Enabled = False
        End If
        'we let the 2nd groupbox show if the user presses the continue button
        GroupBox2.Show()



    End Sub

    Private Sub Button2Continue_Click(sender As Object, e As EventArgs) Handles Button2Continue.Click
        '
        If NUDHeighth.Value = 0 Or NUDWidth.Value = 0 Or NUDLength.Value = 0 Then
            MessageBox.Show("Input measurements")
        Else
            GroupBox2.Enabled = False
            GroupBox3.Enabled = True
        End If
        'we let the 3nd groupbox show if the user presses the continue button
        GroupBox3.Show()

    End Sub

    Private Sub Button4Option_Click(sender As Object, e As EventArgs) Handles Button4Option.Click
        Button1Option.BackColor = SystemColors.Control
        Button2Option.BackColor = SystemColors.Control
        Button3Option.BackColor = SystemColors.Control
        Button4Option.BackColor = SystemColors.Control

    End Sub

    Private Sub TextBox1Name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1Name.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "abcdefghijklmnopqrstuvwxyz "
            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a character")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If

    End Sub

    Private Sub TextBox1Name_TextChanged(sender As Object, e As EventArgs) Handles TextBox1Name.TextChanged

    End Sub

    Private Sub Button2Option_Click(sender As Object, e As EventArgs) Handles Button2Option.Click
        Button1Option.BackColor = SystemColors.Control
        Button2Option.BackColor = SystemColors.Control
        Button3Option.BackColor = SystemColors.Control
        Button4Option.BackColor = SystemColors.Control

    End Sub

    Private Sub Button3Option_Click(sender As Object, e As EventArgs) Handles Button3Option.Click
        Button1Option.BackColor = SystemColors.Control
        Button2Option.BackColor = SystemColors.Control
        Button3Option.BackColor = SystemColors.Control
        Button4Option.BackColor = SystemColors.Control

    End Sub

    Private Sub ButtonPerRol_Click(sender As Object, e As EventArgs) Handles ButtonPerRol.Click
        Dim product_id As Integer = ListBox1Wallpaper.SelectedIndex

        Select Case product_id
            Case 0
                NUDMessage.Value = 10
            Case 1
                NUDMessage.Value = 7.5
            Case 2
                NUDMessage.Value = 8.75
            Case 3
                NUDMessage.Value = 16.5
        End Select
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("This form is divided into three parts: group box 1, group box 2 and group box 3. You must enter your name and address into group box 1. Keep in mind that the name can not contain any numbers or special characters. The address can contain numbers and letters but not special characters. Press continue to unlock and unhide group box 2. 

In group box 2 you must enter the room dimensions such as the length, width and height. After inputting these data, you must press calculate and it will calculate the number of rolls needed. Do keep in mind that the dimensions of each wallpaper are: 5 meters in length and 0.5 metre in width. press continue to unlock and unhide group box 3. 

In group box 3 you must pick a wallpaper from the list and press calculate price per single roll to view the price for a single roll. Only after this can you press calculate to view the total cost. 
")
    End Sub

    Private Sub NUDMessage_ValueChanged(sender As Object, e As EventArgs) Handles NUDMessage.ValueChanged

    End Sub
End Class