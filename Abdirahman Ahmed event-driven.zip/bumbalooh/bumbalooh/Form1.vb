﻿Imports System.Data.SqlClient
Public Class Form1
    Private Sub Button1Login_Click(sender As Object, e As EventArgs) Handles ButtonLogin.Click
            Dim con As New SqlConnection
            Dim cmd As New SqlCommand

        con.ConnectionString = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\bumbalooh\bumbalooh\Database1.mdf;Integrated Security=True"
        con.Open()

        Dim stmt As String = "SELECT * FROM users WHERE email='" & email.Text & "'  AND password='" & password.Text & "' "
        cmd = New SqlCommand(stmt, con)
        Dim reader As SqlDataReader = cmd.ExecuteReader

        If reader.Read Then
            MessageBox.Show("Welcome, you have logged in successfully ")
            Me.Hide()
            f2.Show()
        Else
            MessageBox.Show("Sorry, the login credentials are invalid")
            password.Clear()
        End If
        con.Close()
    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
            Me.Close()
        End Sub

    Private Sub email_TextChanged(sender As Object, e As EventArgs) Handles email.TextChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
