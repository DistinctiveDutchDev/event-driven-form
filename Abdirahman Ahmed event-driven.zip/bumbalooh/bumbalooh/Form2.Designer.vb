﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.LabelName = New System.Windows.Forms.Label()
        Me.LabelAdress = New System.Windows.Forms.Label()
        Me.TextBox1Name = New System.Windows.Forms.TextBox()
        Me.TextBox2Adress = New System.Windows.Forms.TextBox()
        Me.PictureBox1Option = New System.Windows.Forms.PictureBox()
        Me.PictureBox4Option = New System.Windows.Forms.PictureBox()
        Me.PictureBox2Option = New System.Windows.Forms.PictureBox()
        Me.PictureBox3Option = New System.Windows.Forms.PictureBox()
        Me.Button1Option = New System.Windows.Forms.Button()
        Me.Button2Option = New System.Windows.Forms.Button()
        Me.Button3Option = New System.Windows.Forms.Button()
        Me.Button4Option = New System.Windows.Forms.Button()
        Me.NUDHeighth = New System.Windows.Forms.NumericUpDown()
        Me.NUDWidth = New System.Windows.Forms.NumericUpDown()
        Me.NUDLength = New System.Windows.Forms.NumericUpDown()
        Me.LabelHeight = New System.Windows.Forms.Label()
        Me.LabelWidth = New System.Windows.Forms.Label()
        Me.LabelLength = New System.Windows.Forms.Label()
        Me.Label6Room = New System.Windows.Forms.Label()
        Me.Label7Roll = New System.Windows.Forms.Label()
        Me.NUDzerofive = New System.Windows.Forms.NumericUpDown()
        Me.NUDfivezero = New System.Windows.Forms.NumericUpDown()
        Me.LabelPrice = New System.Windows.Forms.Label()
        Me.TextBoxPrice = New System.Windows.Forms.TextBox()
        Me.LabelTotalCost = New System.Windows.Forms.Label()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.Button6Calculate = New System.Windows.Forms.Button()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.ListBox1Wallpaper = New System.Windows.Forms.ListBox()
        Me.Label11Number = New System.Windows.Forms.Label()
        Me.NUDExact = New System.Windows.Forms.NumericUpDown()
        Me.NUDCalculate = New System.Windows.Forms.NumericUpDown()
        Me.Button8Calculate = New System.Windows.Forms.Button()
        Me.Label12Message = New System.Windows.Forms.Label()
        Me.NUDAnswer = New System.Windows.Forms.NumericUpDown()
        Me.NUDApprox = New System.Windows.Forms.NumericUpDown()
        Me.NUDMessage = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ButtonContinue = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button2Continue = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ButtonPerRol = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label = New System.Windows.Forms.Label()
        CType(Me.PictureBox1Option, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4Option, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2Option, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3Option, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDHeighth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDLength, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDzerofive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDfivezero, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDExact, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDCalculate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDAnswer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDApprox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUDMessage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelName
        '
        Me.LabelName.AutoSize = True
        Me.LabelName.Location = New System.Drawing.Point(14, 44)
        Me.LabelName.Name = "LabelName"
        Me.LabelName.Size = New System.Drawing.Size(39, 15)
        Me.LabelName.TabIndex = 0
        Me.LabelName.Text = "Name"
        '
        'LabelAdress
        '
        Me.LabelAdress.AutoSize = True
        Me.LabelAdress.Location = New System.Drawing.Point(11, 70)
        Me.LabelAdress.Name = "LabelAdress"
        Me.LabelAdress.Size = New System.Drawing.Size(42, 15)
        Me.LabelAdress.TabIndex = 1
        Me.LabelAdress.Text = "Adress"
        '
        'TextBox1Name
        '
        Me.TextBox1Name.Location = New System.Drawing.Point(63, 44)
        Me.TextBox1Name.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox1Name.Name = "TextBox1Name"
        Me.TextBox1Name.Size = New System.Drawing.Size(152, 23)
        Me.TextBox1Name.TabIndex = 2
        '
        'TextBox2Adress
        '
        Me.TextBox2Adress.Location = New System.Drawing.Point(63, 70)
        Me.TextBox2Adress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox2Adress.Name = "TextBox2Adress"
        Me.TextBox2Adress.Size = New System.Drawing.Size(152, 23)
        Me.TextBox2Adress.TabIndex = 3
        '
        'PictureBox1Option
        '
        Me.PictureBox1Option.Image = CType(resources.GetObject("PictureBox1Option.Image"), System.Drawing.Image)
        Me.PictureBox1Option.Location = New System.Drawing.Point(21, 21)
        Me.PictureBox1Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1Option.Name = "PictureBox1Option"
        Me.PictureBox1Option.Size = New System.Drawing.Size(123, 65)
        Me.PictureBox1Option.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1Option.TabIndex = 4
        Me.PictureBox1Option.TabStop = False
        '
        'PictureBox4Option
        '
        Me.PictureBox4Option.Image = CType(resources.GetObject("PictureBox4Option.Image"), System.Drawing.Image)
        Me.PictureBox4Option.Location = New System.Drawing.Point(150, 129)
        Me.PictureBox4Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox4Option.Name = "PictureBox4Option"
        Me.PictureBox4Option.Size = New System.Drawing.Size(123, 79)
        Me.PictureBox4Option.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4Option.TabIndex = 5
        Me.PictureBox4Option.TabStop = False
        '
        'PictureBox2Option
        '
        Me.PictureBox2Option.Image = CType(resources.GetObject("PictureBox2Option.Image"), System.Drawing.Image)
        Me.PictureBox2Option.Location = New System.Drawing.Point(150, 21)
        Me.PictureBox2Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox2Option.Name = "PictureBox2Option"
        Me.PictureBox2Option.Size = New System.Drawing.Size(123, 65)
        Me.PictureBox2Option.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2Option.TabIndex = 6
        Me.PictureBox2Option.TabStop = False
        '
        'PictureBox3Option
        '
        Me.PictureBox3Option.Image = CType(resources.GetObject("PictureBox3Option.Image"), System.Drawing.Image)
        Me.PictureBox3Option.Location = New System.Drawing.Point(21, 129)
        Me.PictureBox3Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox3Option.Name = "PictureBox3Option"
        Me.PictureBox3Option.Size = New System.Drawing.Size(123, 79)
        Me.PictureBox3Option.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3Option.TabIndex = 7
        Me.PictureBox3Option.TabStop = False
        '
        'Button1Option
        '
        Me.Button1Option.BackColor = System.Drawing.Color.White
        Me.Button1Option.Location = New System.Drawing.Point(21, 90)
        Me.Button1Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button1Option.Name = "Button1Option"
        Me.Button1Option.Size = New System.Drawing.Size(123, 22)
        Me.Button1Option.TabIndex = 8
        Me.Button1Option.Text = "Abstract Triangles"
        Me.Button1Option.UseVisualStyleBackColor = False
        '
        'Button2Option
        '
        Me.Button2Option.BackColor = System.Drawing.Color.White
        Me.Button2Option.Location = New System.Drawing.Point(150, 90)
        Me.Button2Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2Option.Name = "Button2Option"
        Me.Button2Option.Size = New System.Drawing.Size(123, 22)
        Me.Button2Option.TabIndex = 9
        Me.Button2Option.Text = "Greenhouse Plants"
        Me.Button2Option.UseVisualStyleBackColor = False
        '
        'Button3Option
        '
        Me.Button3Option.BackColor = System.Drawing.Color.White
        Me.Button3Option.Location = New System.Drawing.Point(21, 212)
        Me.Button3Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button3Option.Name = "Button3Option"
        Me.Button3Option.Size = New System.Drawing.Size(123, 22)
        Me.Button3Option.TabIndex = 10
        Me.Button3Option.Text = "VelvetFoilTrellis"
        Me.Button3Option.UseVisualStyleBackColor = False
        '
        'Button4Option
        '
        Me.Button4Option.BackColor = System.Drawing.Color.White
        Me.Button4Option.Location = New System.Drawing.Point(150, 212)
        Me.Button4Option.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button4Option.Name = "Button4Option"
        Me.Button4Option.Size = New System.Drawing.Size(123, 22)
        Me.Button4Option.TabIndex = 11
        Me.Button4Option.Text = "VWVolkswagen"
        Me.Button4Option.UseVisualStyleBackColor = False
        '
        'NUDHeighth
        '
        Me.NUDHeighth.DecimalPlaces = 1
        Me.NUDHeighth.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NUDHeighth.Location = New System.Drawing.Point(9, 117)
        Me.NUDHeighth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDHeighth.Name = "NUDHeighth"
        Me.NUDHeighth.Size = New System.Drawing.Size(62, 23)
        Me.NUDHeighth.TabIndex = 12
        '
        'NUDWidth
        '
        Me.NUDWidth.DecimalPlaces = 1
        Me.NUDWidth.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NUDWidth.Location = New System.Drawing.Point(76, 117)
        Me.NUDWidth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDWidth.Name = "NUDWidth"
        Me.NUDWidth.Size = New System.Drawing.Size(62, 23)
        Me.NUDWidth.TabIndex = 13
        '
        'NUDLength
        '
        Me.NUDLength.DecimalPlaces = 1
        Me.NUDLength.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NUDLength.Location = New System.Drawing.Point(155, 117)
        Me.NUDLength.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDLength.Name = "NUDLength"
        Me.NUDLength.Size = New System.Drawing.Size(62, 23)
        Me.NUDLength.TabIndex = 14
        '
        'LabelHeight
        '
        Me.LabelHeight.AutoSize = True
        Me.LabelHeight.Location = New System.Drawing.Point(9, 100)
        Me.LabelHeight.Name = "LabelHeight"
        Me.LabelHeight.Size = New System.Drawing.Size(43, 15)
        Me.LabelHeight.TabIndex = 15
        Me.LabelHeight.Text = "Height"
        '
        'LabelWidth
        '
        Me.LabelWidth.AutoSize = True
        Me.LabelWidth.Location = New System.Drawing.Point(76, 100)
        Me.LabelWidth.Name = "LabelWidth"
        Me.LabelWidth.Size = New System.Drawing.Size(39, 15)
        Me.LabelWidth.TabIndex = 16
        Me.LabelWidth.Text = "Width"
        '
        'LabelLength
        '
        Me.LabelLength.AutoSize = True
        Me.LabelLength.Location = New System.Drawing.Point(155, 100)
        Me.LabelLength.Name = "LabelLength"
        Me.LabelLength.Size = New System.Drawing.Size(44, 15)
        Me.LabelLength.TabIndex = 17
        Me.LabelLength.Text = "Length"
        '
        'Label6Room
        '
        Me.Label6Room.AutoSize = True
        Me.Label6Room.Font = New System.Drawing.Font("Segoe UI", 10.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label6Room.Location = New System.Drawing.Point(9, 74)
        Me.Label6Room.Name = "Label6Room"
        Me.Label6Room.Size = New System.Drawing.Size(137, 20)
        Me.Label6Room.TabIndex = 18
        Me.Label6Room.Text = "Room dimensions"
        '
        'Label7Roll
        '
        Me.Label7Roll.AutoSize = True
        Me.Label7Roll.Font = New System.Drawing.Font("Segoe UI", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label7Roll.Location = New System.Drawing.Point(9, 19)
        Me.Label7Roll.Name = "Label7Roll"
        Me.Label7Roll.Size = New System.Drawing.Size(110, 19)
        Me.Label7Roll.TabIndex = 19
        Me.Label7Roll.Text = "Roll dimensions"
        '
        'NUDzerofive
        '
        Me.NUDzerofive.DecimalPlaces = 1
        Me.NUDzerofive.Enabled = False
        Me.NUDzerofive.Location = New System.Drawing.Point(9, 46)
        Me.NUDzerofive.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDzerofive.Name = "NUDzerofive"
        Me.NUDzerofive.ReadOnly = True
        Me.NUDzerofive.Size = New System.Drawing.Size(62, 23)
        Me.NUDzerofive.TabIndex = 20
        Me.NUDzerofive.Value = New Decimal(New Integer() {5, 0, 0, 65536})
        '
        'NUDfivezero
        '
        Me.NUDfivezero.DecimalPlaces = 1
        Me.NUDfivezero.Enabled = False
        Me.NUDfivezero.Location = New System.Drawing.Point(77, 46)
        Me.NUDfivezero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDfivezero.Name = "NUDfivezero"
        Me.NUDfivezero.ReadOnly = True
        Me.NUDfivezero.Size = New System.Drawing.Size(62, 23)
        Me.NUDfivezero.TabIndex = 21
        Me.NUDfivezero.Value = New Decimal(New Integer() {50, 0, 0, 65536})
        '
        'LabelPrice
        '
        Me.LabelPrice.AutoSize = True
        Me.LabelPrice.Font = New System.Drawing.Font("Segoe UI", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.LabelPrice.Location = New System.Drawing.Point(6, 360)
        Me.LabelPrice.Name = "LabelPrice"
        Me.LabelPrice.Size = New System.Drawing.Size(29, 19)
        Me.LabelPrice.TabIndex = 22
        Me.LabelPrice.Text = "   £"
        '
        'TextBoxPrice
        '
        Me.TextBoxPrice.Location = New System.Drawing.Point(41, 359)
        Me.TextBoxPrice.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxPrice.Name = "TextBoxPrice"
        Me.TextBoxPrice.Size = New System.Drawing.Size(118, 23)
        Me.TextBoxPrice.TabIndex = 23
        '
        'LabelTotalCost
        '
        Me.LabelTotalCost.AutoSize = True
        Me.LabelTotalCost.Font = New System.Drawing.Font("Segoe UI", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.LabelTotalCost.Location = New System.Drawing.Point(41, 330)
        Me.LabelTotalCost.Name = "LabelTotalCost"
        Me.LabelTotalCost.Size = New System.Drawing.Size(74, 19)
        Me.LabelTotalCost.TabIndex = 26
        Me.LabelTotalCost.Text = "Total Cost"
        '
        'ButtonClear
        '
        Me.ButtonClear.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonClear.Location = New System.Drawing.Point(875, 428)
        Me.ButtonClear.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(86, 31)
        Me.ButtonClear.TabIndex = 28
        Me.ButtonClear.Text = "Clear"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'Button6Calculate
        '
        Me.Button6Calculate.BackColor = System.Drawing.Color.LightGray
        Me.Button6Calculate.Location = New System.Drawing.Point(9, 173)
        Me.Button6Calculate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button6Calculate.Name = "Button6Calculate"
        Me.Button6Calculate.Size = New System.Drawing.Size(82, 22)
        Me.Button6Calculate.TabIndex = 29
        Me.Button6Calculate.Text = "Calculate"
        Me.Button6Calculate.UseVisualStyleBackColor = False
        '
        'ButtonExit
        '
        Me.ButtonExit.BackColor = System.Drawing.Color.Red
        Me.ButtonExit.Location = New System.Drawing.Point(967, 428)
        Me.ButtonExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(92, 31)
        Me.ButtonExit.TabIndex = 30
        Me.ButtonExit.Text = "Exit"
        Me.ButtonExit.UseVisualStyleBackColor = False
        '
        'ListBox1Wallpaper
        '
        Me.ListBox1Wallpaper.FormattingEnabled = True
        Me.ListBox1Wallpaper.ItemHeight = 15
        Me.ListBox1Wallpaper.Items.AddRange(New Object() {"Abstracttriangle £10", "Greenhouse Plants £7.50", "VelvetFoilTrellis £8.75", "VWVolkswagen £16.50"})
        Me.ListBox1Wallpaper.Location = New System.Drawing.Point(279, 90)
        Me.ListBox1Wallpaper.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ListBox1Wallpaper.Name = "ListBox1Wallpaper"
        Me.ListBox1Wallpaper.Size = New System.Drawing.Size(169, 79)
        Me.ListBox1Wallpaper.TabIndex = 31
        '
        'Label11Number
        '
        Me.Label11Number.AutoSize = True
        Me.Label11Number.Font = New System.Drawing.Font("Segoe UI", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label11Number.Location = New System.Drawing.Point(9, 224)
        Me.Label11Number.Name = "Label11Number"
        Me.Label11Number.Size = New System.Drawing.Size(169, 19)
        Me.Label11Number.TabIndex = 33
        Me.Label11Number.Text = "Number of rolls required"
        '
        'NUDExact
        '
        Me.NUDExact.DecimalPlaces = 1
        Me.NUDExact.Enabled = False
        Me.NUDExact.Location = New System.Drawing.Point(9, 245)
        Me.NUDExact.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDExact.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUDExact.Name = "NUDExact"
        Me.NUDExact.ReadOnly = True
        Me.NUDExact.Size = New System.Drawing.Size(187, 23)
        Me.NUDExact.TabIndex = 34
        '
        'NUDCalculate
        '
        Me.NUDCalculate.DecimalPlaces = 1
        Me.NUDCalculate.Enabled = False
        Me.NUDCalculate.Location = New System.Drawing.Point(41, 306)
        Me.NUDCalculate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDCalculate.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUDCalculate.Name = "NUDCalculate"
        Me.NUDCalculate.ReadOnly = True
        Me.NUDCalculate.Size = New System.Drawing.Size(118, 23)
        Me.NUDCalculate.TabIndex = 35
        '
        'Button8Calculate
        '
        Me.Button8Calculate.BackColor = System.Drawing.Color.Silver
        Me.Button8Calculate.Location = New System.Drawing.Point(160, 333)
        Me.Button8Calculate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button8Calculate.Name = "Button8Calculate"
        Me.Button8Calculate.Size = New System.Drawing.Size(113, 22)
        Me.Button8Calculate.TabIndex = 37
        Me.Button8Calculate.Text = "Calculate price"
        Me.Button8Calculate.UseVisualStyleBackColor = False
        '
        'Label12Message
        '
        Me.Label12Message.AutoSize = True
        Me.Label12Message.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label12Message.Location = New System.Drawing.Point(97, 175)
        Me.Label12Message.Name = "Label12Message"
        Me.Label12Message.Size = New System.Drawing.Size(82, 17)
        Me.Label12Message.TabIndex = 38
        Me.Label12Message.Text = "divide by 2.5"
        '
        'NUDAnswer
        '
        Me.NUDAnswer.DecimalPlaces = 1
        Me.NUDAnswer.Enabled = False
        Me.NUDAnswer.Location = New System.Drawing.Point(9, 146)
        Me.NUDAnswer.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDAnswer.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUDAnswer.Name = "NUDAnswer"
        Me.NUDAnswer.ReadOnly = True
        Me.NUDAnswer.Size = New System.Drawing.Size(131, 23)
        Me.NUDAnswer.TabIndex = 39
        '
        'NUDApprox
        '
        Me.NUDApprox.DecimalPlaces = 1
        Me.NUDApprox.Enabled = False
        Me.NUDApprox.Location = New System.Drawing.Point(9, 199)
        Me.NUDApprox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDApprox.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUDApprox.Name = "NUDApprox"
        Me.NUDApprox.ReadOnly = True
        Me.NUDApprox.Size = New System.Drawing.Size(187, 23)
        Me.NUDApprox.TabIndex = 40
        '
        'NUDMessage
        '
        Me.NUDMessage.DecimalPlaces = 1
        Me.NUDMessage.Enabled = False
        Me.NUDMessage.Location = New System.Drawing.Point(279, 199)
        Me.NUDMessage.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NUDMessage.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUDMessage.Name = "NUDMessage"
        Me.NUDMessage.ReadOnly = True
        Me.NUDMessage.Size = New System.Drawing.Size(124, 23)
        Me.NUDMessage.TabIndex = 41
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.PeachPuff
        Me.GroupBox1.Controls.Add(Me.ButtonContinue)
        Me.GroupBox1.Controls.Add(Me.TextBox1Name)
        Me.GroupBox1.Controls.Add(Me.LabelName)
        Me.GroupBox1.Controls.Add(Me.LabelAdress)
        Me.GroupBox1.Controls.Add(Me.TextBox2Adress)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(239, 158)
        Me.GroupBox1.TabIndex = 42
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'ButtonContinue
        '
        Me.ButtonContinue.BackColor = System.Drawing.Color.Silver
        Me.ButtonContinue.Location = New System.Drawing.Point(123, 120)
        Me.ButtonContinue.Name = "ButtonContinue"
        Me.ButtonContinue.Size = New System.Drawing.Size(113, 25)
        Me.ButtonContinue.TabIndex = 4
        Me.ButtonContinue.Text = "Continue"
        Me.ButtonContinue.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.PeachPuff
        Me.GroupBox2.Controls.Add(Me.Button2Continue)
        Me.GroupBox2.Controls.Add(Me.NUDLength)
        Me.GroupBox2.Controls.Add(Me.NUDHeighth)
        Me.GroupBox2.Controls.Add(Me.Label12Message)
        Me.GroupBox2.Controls.Add(Me.NUDWidth)
        Me.GroupBox2.Controls.Add(Me.NUDApprox)
        Me.GroupBox2.Controls.Add(Me.LabelHeight)
        Me.GroupBox2.Controls.Add(Me.NUDAnswer)
        Me.GroupBox2.Controls.Add(Me.LabelWidth)
        Me.GroupBox2.Controls.Add(Me.LabelLength)
        Me.GroupBox2.Controls.Add(Me.Label6Room)
        Me.GroupBox2.Controls.Add(Me.Label7Roll)
        Me.GroupBox2.Controls.Add(Me.NUDExact)
        Me.GroupBox2.Controls.Add(Me.NUDzerofive)
        Me.GroupBox2.Controls.Add(Me.Label11Number)
        Me.GroupBox2.Controls.Add(Me.NUDfivezero)
        Me.GroupBox2.Controls.Add(Me.Button6Calculate)
        Me.GroupBox2.Location = New System.Drawing.Point(275, 11)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(240, 307)
        Me.GroupBox2.TabIndex = 43
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GroupBox2"
        '
        'Button2Continue
        '
        Me.Button2Continue.BackColor = System.Drawing.Color.Silver
        Me.Button2Continue.Location = New System.Drawing.Point(47, 273)
        Me.Button2Continue.Name = "Button2Continue"
        Me.Button2Continue.Size = New System.Drawing.Size(75, 23)
        Me.Button2Continue.TabIndex = 41
        Me.Button2Continue.Text = "Continue"
        Me.Button2Continue.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.PeachPuff
        Me.GroupBox3.Controls.Add(Me.ButtonPerRol)
        Me.GroupBox3.Controls.Add(Me.ListBox1Wallpaper)
        Me.GroupBox3.Controls.Add(Me.PictureBox1Option)
        Me.GroupBox3.Controls.Add(Me.PictureBox4Option)
        Me.GroupBox3.Controls.Add(Me.NUDMessage)
        Me.GroupBox3.Controls.Add(Me.PictureBox2Option)
        Me.GroupBox3.Controls.Add(Me.PictureBox3Option)
        Me.GroupBox3.Controls.Add(Me.Button8Calculate)
        Me.GroupBox3.Controls.Add(Me.Button1Option)
        Me.GroupBox3.Controls.Add(Me.NUDCalculate)
        Me.GroupBox3.Controls.Add(Me.Button2Option)
        Me.GroupBox3.Controls.Add(Me.Button3Option)
        Me.GroupBox3.Controls.Add(Me.Button4Option)
        Me.GroupBox3.Controls.Add(Me.LabelPrice)
        Me.GroupBox3.Controls.Add(Me.LabelTotalCost)
        Me.GroupBox3.Controls.Add(Me.TextBoxPrice)
        Me.GroupBox3.Location = New System.Drawing.Point(558, 11)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(485, 390)
        Me.GroupBox3.TabIndex = 44
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GroupBox3"
        '
        'ButtonPerRol
        '
        Me.ButtonPerRol.Location = New System.Drawing.Point(279, 171)
        Me.ButtonPerRol.Name = "ButtonPerRol"
        Me.ButtonPerRol.Size = New System.Drawing.Size(186, 23)
        Me.ButtonPerRol.TabIndex = 42
        Me.ButtonPerRol.Text = "Calculate cost per single roll"
        Me.ButtonPerRol.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Yellow
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(0, 404)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(366, 34)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "Press me"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label.Location = New System.Drawing.Point(3, 371)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(62, 30)
        Me.Label.TabIndex = 46
        Me.Label.Text = "HELP"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1167, 474)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.ButtonClear)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form2"
        Me.Text = "Wallpaper Application"
        CType(Me.PictureBox1Option, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4Option, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2Option, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3Option, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDHeighth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDLength, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDzerofive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDfivezero, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDExact, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDCalculate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDAnswer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDApprox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUDMessage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1Name As Label
    Friend WithEvents Label2Adress As Label
    Friend WithEvents TextBox1Name As TextBox
    Friend WithEvents TextBox2Adress As TextBox
    Friend WithEvents PictureBox1Option As PictureBox
    Friend WithEvents PictureBox4Option As PictureBox
    Friend WithEvents PictureBox2Option As PictureBox
    Friend WithEvents PictureBox3Option As PictureBox
    Friend WithEvents Button1Option As Button
    Friend WithEvents Button2Option As Button
    Friend WithEvents Button3Option As Button
    Friend WithEvents Button4Option As Button
    Friend WithEvents NUD1Heighth As NumericUpDown
    Friend WithEvents NUD2Width As NumericUpDown
    Friend WithEvents NUD3Length As NumericUpDown
    Friend WithEvents Label3Height As Label
    Friend WithEvents Label4Width As Label
    Friend WithEvents Label5Length As Label
    Friend WithEvents Label6Room As Label
    Friend WithEvents Label7Roll As Label
    Friend WithEvents NumericUpDown4 As NumericUpDown
    Friend WithEvents NumericUpDown5 As NumericUpDown
    Friend WithEvents Label8Price As Label
    Friend WithEvents TextBox3Price As TextBox
    Friend WithEvents Label10TotalCost As Label
    Friend WithEvents Button5Clear As Button
    Friend WithEvents Button6Calculate As Button
    Friend WithEvents Button7Exit As Button
    Friend WithEvents ListBox1Wallpaper As ListBox
    Friend WithEvents NumericUpDown9Division As NumericUpDown
    Friend WithEvents Label11Number As Label
    Friend WithEvents NumericUpDown10Exact As NumericUpDown
    Friend WithEvents NumericUpDown8Calculate As NumericUpDown
    Friend WithEvents Label12Price As Label
    Friend WithEvents Button8Calculate As Button
    Friend WithEvents Label12Message As Label
    Friend WithEvents NumericUpDown12Approx As NumericUpDown
    Friend WithEvents NumericUpDown1Answer As NumericUpDown
    Friend WithEvents NumericUpDown11Answer As NumericUpDown
    Friend WithEvents NUD11Answer As NumericUpDown
    Friend WithEvents NUD2Approx As NumericUpDown
    Friend WithEvents NUD10Exact As NumericUpDown
    Friend WithEvents NUDHeighth As NumericUpDown
    Friend WithEvents NUDWidth As NumericUpDown
    Friend WithEvents NUDLength As NumericUpDown
    Friend WithEvents NUDExact As NumericUpDown
    Friend WithEvents NUDAnswer As NumericUpDown
    Friend WithEvents NUDApprox As NumericUpDown
    Friend WithEvents LabelName As Label
    Friend WithEvents LabelAdress As Label
    Friend WithEvents LabelHeight As Label
    Friend WithEvents LabelWidth As Label
    Friend WithEvents LabelLength As Label
    Friend WithEvents NUDzerofive As NumericUpDown
    Friend WithEvents NUDfivezero As NumericUpDown
    Friend WithEvents LabelPrice As Label
    Friend WithEvents TextBoxPrice As TextBox
    Friend WithEvents LabelTotalCost As Label
    Friend WithEvents ButtonClear As Button
    Friend WithEvents ButtonExit As Button
    Friend WithEvents NUDDivision As NumericUpDown
    Friend WithEvents NUDCalculate As NumericUpDown
    Friend WithEvents NUDMessage As NumericUpDown
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ButtonContinue As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Button2Continue As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents ButtonPerRol As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label As Label
End Class
