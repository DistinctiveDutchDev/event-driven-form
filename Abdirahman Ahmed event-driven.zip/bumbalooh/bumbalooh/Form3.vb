﻿Public Class Form0
    Private Sub Button_Login_Click(sender As Object, e As EventArgs) Handles Button_Login.Click
        Me.Hide()
        f1.Show()

    End Sub

    Private Sub Button_register_Click(sender As Object, e As EventArgs) Handles Button_register.Click
        Me.Hide()
        f4.Show()

    End Sub

    Private Sub Form0_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class