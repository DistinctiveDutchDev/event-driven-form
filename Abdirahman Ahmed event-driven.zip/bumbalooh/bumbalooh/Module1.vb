﻿Module Module1
    Public f0 As New Form0
    Public f1 As New Form1
    Public f2 As New Form2
    Public f4 As New Form4


End Module
