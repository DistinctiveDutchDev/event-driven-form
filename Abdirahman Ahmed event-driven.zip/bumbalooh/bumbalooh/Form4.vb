﻿Imports System.Data.SqlClient

Public Class Form4
    Private Sub ButtonRegister_Click(sender As Object, e As EventArgs) Handles ButtonRegister.Click
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand

        con.ConnectionString = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\bumbalooh\bumbalooh\Database1.mdf;Integrated Security=True"
        con.Open()

        If (fname.Text = "" Or lname.Text = "" Or gender.Text = "" Or phone.Text = "" Or email.Text = "" Or password.Text = "") Then
            MessageBox.Show("Please Enter All Fields")

        Else
            cmd = New SqlCommand("INSERT INTO users values('" & fname.Text & "','" & lname.Text & "','" & gender.Text & "','" & phone.Text & "','" & email.Text & "','" & password.Text & "') ", con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("You have successfully registered with us")
            Me.Hide()
            f1.Show()
            fname.Clear()
            lname.Clear()
            phone.Clear()
            email.Clear()
            password.Clear()

        End If




    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        Me.Close()
    End Sub

    Private Sub fname_keypress(sender As Object, e As KeyPressEventArgs) Handles fname.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "abcdefghijklmnopqrstuvwxyz"
            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a valid character")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If
    End Sub

    Private Sub phone_keypress(sender As Object, e As KeyPressEventArgs) Handles phone.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "1234567890"
            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a valid phonenumber")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If
    End Sub

    Private Sub lname_keypress(sender As Object, e As KeyPressEventArgs) Handles lname.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "abcdefghijklmnopqrstuvwxyz"
            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a valid character")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If
    End Sub

    Private Sub email_keypress(sender As Object, e As KeyPressEventArgs) Handles email.KeyPress
        'we are restricting the user from utilising characters that are not needed
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "1234567890abcdefghijklmnopqrstuvwxyz@."
            If Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please enter a valid character")
                e.KeyChar = ChrW(0)
                e.Handled = True

            End If
        End If
    End Sub

    Private Sub fname_TextChanged(sender As Object, e As EventArgs) Handles fname.TextChanged

    End Sub

    Private Sub email_TextChanged(sender As Object, e As EventArgs) Handles email.TextChanged

    End Sub

    Private Sub phone_TextChanged(sender As Object, e As EventArgs) Handles phone.TextChanged

    End Sub

    Private Sub password_TextChanged(sender As Object, e As EventArgs) Handles password.TextChanged

    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
